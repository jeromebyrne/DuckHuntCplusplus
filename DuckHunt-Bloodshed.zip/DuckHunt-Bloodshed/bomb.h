//Author: Jerome Byrne
#include "vector.h"
#ifndef BOMB_H
#define BOMB_H
class Bomb{
      private:
              Vector position;
              Vector destination;
              HBITMAP hBtmpBitmap;
              HBITMAP hBtmpBitMask;
              bool d_show;
      public:
             Bomb(float posx=rand()%600,float posy=-70,char* bitmap,char* bitmask)
             {
                    d_show=false;
                    position.setX(posx);
                    position.setY(posy);
                    destination.setX(rand()%500);
                    destination.setY(600);
                    hBtmpBitmap=(HBITMAP)LoadImage(
                    NULL,			// dont worry, leave as null
				    bitmap,	// name of the file to be loaded
				    IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				    0,				// leave as 0
				    0,				// leave as 0
				    LR_LOADFROMFILE
				    );  
                    hBtmpBitMask=(HBITMAP)LoadImage(
                    NULL,			// dont worry, leave as null
				    bitmask,	// name of the file to be loaded
				    IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				    0,				// leave as 0
				    0,				// leave as 0
				    LR_LOADFROMFILE
				    );  
             }
             ~Bomb()
             {
                    DeleteObject(hBtmpBitmap);
                    DeleteObject(hBtmpBitMask);
             }
             Vector pos() const
             {
                    return position;
             }
             Vector dest() const
             {
                    return destination;
             }
             void setDest(float x,float y)
             {
                  destination.setX(x);
                  destination.setY(y);
             }
             void setPos(float x,float y)
             {
                  position.setX(x);
                  position.setY(y);
              }
             bool show()const
             {
                  return d_show;
             }
             void setShow(bool b)
             {
                  d_show=b;
             }
             HBITMAP getBitMask() const
             {
                     return hBtmpBitMask;
             }
             HBITMAP getBitmap() const
             {
                     return hBtmpBitmap;
             }
             float x()const
             {
                   return position.x();
             }
             float y()const
             {
                   return position.y();
             }
             void move(float speed)
             {
                  Vector dir(Vector::direction(position,destination));
                  dir.setX(dir.x()*speed);
                  dir.setY(dir.y()*speed);
                  position.setX((position.x()+dir.x()));
			      position.setY((position.y()+dir.y()));
             }
      };
#endif
