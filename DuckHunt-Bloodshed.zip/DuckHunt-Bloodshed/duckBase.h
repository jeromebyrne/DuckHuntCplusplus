//Author: Jerome Byrne

#ifndef DUCKBASE_H
#define DUCKBASE_H

class DuckBase
{
	private:
		bool d_show;
		int	d_x;
		int d_y;
		bool d_shot;
		bool d_decapitated;
		bool d_torsoShot;
		bool d_massacred;
		float d_xSpeed;
		float d_ySpeed;
		HBITMAP hBtmpDuck;
		HBITMAP hBtmpDuckMask;
		HBITMAP hBtmpWingless;
		HBITMAP hBtmpWinglessMask;
        HBITMAP hBtmpDuckTorso;
        HBITMAP hBtmpDuckTorsoMask;
        HBITMAP hBtmpHeadless;
        HBITMAP hBtmpHeadlessMask;
        HBITMAP hBtmpMassacred;
        HBITMAP hBtmpLimbless;
        HBITMAP hBtmpLimblessMask;
        HBITMAP hBtmpDestroyed;
        HBITMAP hBtmpMess;
		RECT DuckRt;
		BITMAP bmDuck;
		bool d_wingless;
		bool d_limbless;
		bool d_destroyed;
	public:
		
		DuckBase(int x=0, int y=rand()%275,char* s="ducky.bmp",char* sMask="duckyMask.bmp",float xspeed=(rand()%4)+1,float yspeed=2.5)
		{
			d_x=x;
			d_y=y;
			d_show=false;
			d_shot=false;
			d_decapitated=false;
			d_massacred=false;
			d_wingless=false;
			d_destroyed=false;
			d_limbless=false;
			d_torsoShot;
			d_xSpeed=xspeed;
			d_ySpeed=yspeed;
			hBtmpDuck=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				s,	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);

			hBtmpDuckMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				sMask,	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpDuckTorso=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"torso.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpMess=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"mess.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpWingless=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"wingless.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpWinglessMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"winglessmask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpHeadless=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"headless.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpHeadlessMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"headlessMask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpMassacred=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"Massacre.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpLimbless=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"limbless.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpLimblessMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"limblessmask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			hBtmpDestroyed=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"destroyed.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			//RECTANGLE AROUND DUCK1
			GetObject(hBtmpDuck,sizeof(BITMAP), (LPVOID)&bmDuck);
			DuckRt.bottom=bmDuck.bmHeight;
			DuckRt.right=bmDuck.bmWidth;
      }
		~DuckBase()
		{
			DeleteObject(hBtmpDuck);
			DeleteObject(hBtmpDuckMask);
			DeleteObject(hBtmpDuckTorso);
			DeleteObject(hBtmpDuckTorsoMask);
			DeleteObject(hBtmpHeadless);
			DeleteObject(hBtmpHeadlessMask);
		    DeleteObject(hBtmpMassacred);
		    DeleteObject(hBtmpWingless);
		    DeleteObject(hBtmpWinglessMask);
		    DeleteObject(hBtmpDestroyed);
		    DeleteObject(hBtmpLimbless);
		    DeleteObject(hBtmpLimblessMask);
		    DeleteObject(hBtmpMess);
         }
        void setLimbless(bool b)
        {
             d_limbless=b;
        } 
        bool limbless()
        {
             return d_limbless;
        }
        void setDestroyed(bool b)
        {
             d_destroyed=b;
        }
        bool destroyed()
        {
             return d_destroyed;
        } 
		void setMassacred(bool m)
		{
             d_massacred=m;
         }
		bool massacred()
		{
             return d_massacred;
         }
        void setWingless(bool b)
        {
             d_wingless=b;
        }
        bool wingless()
        {
             return d_wingless;
        }
		void setTorsoShot(bool t)
		{
             d_torsoShot=t;
         }
		bool torsoShot()
		{
             return d_torsoShot;
         }
	    void setDecap(bool d)
	    {
             d_decapitated=d;
                  }
		bool decapitated()
		{
             return d_decapitated;
         };
		void setBitmap(char b)
		{
             if(b=='t')//if the duck has been shot in the 't'orso
             {
                  hBtmpDuck=hBtmpDuckTorso; 
                  //hBtmpDuckMask=hBtmpDuckTorsoMask;
             }
             else if(b=='h')//if the duck has been shot in the 'h'ead
             {
                  hBtmpDuck=hBtmpHeadless;
                  hBtmpDuckMask=hBtmpHeadlessMask;          
             }
             else if(b=='w')
             {
                  hBtmpDuck=hBtmpWingless;
                  hBtmpDuckMask=hBtmpWinglessMask;
             }
             else if(b=='m')//if the duck has been shot in the body and head/'m'assacred
             {
                            hBtmpDuck=hBtmpMassacred;
                            hBtmpDuckMask=hBtmpHeadlessMask;
             }
             else if(b=='l')
             {
                  hBtmpDuck=hBtmpLimbless;
                  hBtmpDuckMask=hBtmpLimblessMask;
             }
             else if(b=='M')
             {
                  hBtmpDuck=hBtmpMess;
                  hBtmpDuckMask=hBtmpWinglessMask;
             }
             else if(b=='d')
             {
                  hBtmpDuck=hBtmpDestroyed;
                  hBtmpDuckMask=hBtmpLimblessMask;
             }
         }
		void delBitmaps()
		{
			DeleteObject(hBtmpDuck);
			DeleteObject(hBtmpDuckMask);
		}
		void shotDown()
		{
			d_shot=true;	
		}
		bool getShotDown() const
		{
			return d_shot;
		}
		float getRtB() 
		{

			return(DuckRt.bottom=bmDuck.bmHeight);
		}
		float getRtR() 
		{
			return(DuckRt.right=bmDuck.bmWidth);
		}
		HBITMAP getBitmap() const
		{
			
			return hBtmpDuck;
		}
		HBITMAP getBitMask() const
		{
			
			return hBtmpDuckMask;
		}
	
		bool show()
		{
			return d_show;
		}
		void setShow(bool show)
		{
			if(show==true)
			{
				d_show=true;
			}
			else if(show==false)
				d_show=false;
			
		}
		
		void setX(int x)
		{
			d_x=x;
		}
		void setY(int y)
		{
			d_y=y;
		}
		int getX() const
		{
			return d_x;
		}
		int getY() const
		{
			return d_y;
		}
		float xSpeed() const{
			return d_xSpeed;
		}
		float ySpeed() const{
			return d_ySpeed;
		}
		void setXspeed(float x){
			d_xSpeed=x;

		}
		void setYspeed(float y){
			d_ySpeed=y;

		}
		RECT rect() const
		{
               return DuckRt;
        }
};

#endif
