//Author: Jerome Byrne
#ifndef GUN_H
#define GUN_H

class Gun{//start of class gun

private:
    POINT position;
	float d_preX;
	float d_preY;
	HBITMAP hBtmpTarget; //this contains the current target bitmap
	HBITMAP hBtmpTargetMask;
	HBITMAP hBtmpNormalTargetMask;//this the regular target bitmap
	HBITMAP hBtmpNormalTarget;
	HBITMAP hBtmpRedTargetMask;//this is the locked on bitmap
	HBITMAP hBtmpRedTarget;
	HBITMAP hBtmpFlash;//this is the muzzle flash bitmap
	HBITMAP hBtmpFlashMask;
	HBITMAP hBtmpScope;
	int d_flash;
	bool d_reLoaded;
	int d_maxClip;
	int d_clipSize;
	bool d_jammed;
	bool d_shoot;
public:
	Gun(int x=350,int y=300)//member initialiser list
	{
        position.x=x;
        position.y=y;
        d_shoot=false;
        d_jammed=false;
        d_maxClip=3;
        d_clipSize=d_maxClip;
        d_reLoaded=true;
        d_flash=10;
        hBtmpScope=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"scope.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
		hBtmpNormalTarget=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"target.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);

		hBtmpNormalTargetMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"targetMask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
		hBtmpRedTarget=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"redTarget.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);

		hBtmpRedTargetMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"redTargetMask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
		hBtmpFlash=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"muzzleFlash.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
		hBtmpFlashMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"muzzleFlashMask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);

		HBITMAP hBtmpTarget=hBtmpNormalTarget; 
		HBITMAP hBtmpTargetMask=hBtmpNormalTargetMask;
	}
	bool shoot() const
	{
         return d_shoot;
    }
	void setShoot(bool s)
	{
         d_shoot=s;
    }
	bool jammed() const
	{
         return d_jammed;
    }
    void setJammed(bool j)
    {
         d_jammed=j;
    }
	int maxClip() const
	{
        return d_maxClip;
    }
    int clipSize()
    {
        return d_clipSize;
    }
    void setClipSize(int c)
    {
         d_clipSize=c;
    }
	bool reloaded() const
	{
         return d_reLoaded;
     }
    void reload(bool r)
    {
         d_reLoaded=r;
     }
    int flashTime()const//return the max muzzle flash time
    {
        return d_flash;
    }
    void setFlashTime(int f)
    {
         d_flash=f;
     }
	HBITMAP getBitmap()
	{
			
		return hBtmpTarget;
	}
	HBITMAP getBitMask()
	{
			
		return hBtmpTargetMask;
	}
	HBITMAP getFlash()
	{
			
		return hBtmpFlash;
	}
	HBITMAP getFlashMask()
	{
			
		return hBtmpFlashMask;
	}
	void setBitmap(char b){
		if(b=='r')
		{
			hBtmpTarget=hBtmpRedTarget;
			hBtmpTargetMask=hBtmpRedTargetMask;
		}
		else if(b==' ')
        { 
			 hBtmpTarget=hBtmpNormalTarget; // hBtmp is a handle to a bitmap
			 hBtmpTargetMask=hBtmpNormalTargetMask;
        }
        else if(b=='s')
        {
             hBtmpTarget=hBtmpScope;
        }       

	}
	void setPreX(float x)
	{
         d_preX=x;
    }
    void setPreY(float y)
    {
         d_preY=y;
     }
    float preX()
    {
          return d_preX;
    }
    float preY()
    {
          return d_preY;
    }
    POINT point()
    {
          return position;
    } 
	void setX(float x)
	{position.x=x;}
	void setY(float y)
	{position.y=y;}
	float getX()
	{return position.x;}
	float getY()
	{return position.y;}
	~Gun()
	{
		DeleteObject(hBtmpTarget);
		DeleteObject(hBtmpTargetMask);
		DeleteObject(hBtmpFlash);
		DeleteObject(hBtmpFlashMask);
	}

};//end of class gun

#endif
