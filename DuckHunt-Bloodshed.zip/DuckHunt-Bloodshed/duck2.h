//Author: Jerome Byrne
#include "Vector.h"
#include <cmath>
#include "DuckBase.h"
#ifndef DUCK2_H
#define DUCK2_H
class Duck2:public DuckBase{//inherits from duck base
	private:
		Vector d_CurrentPos;//the ducks position
		Vector d_Destination;//the direction the duck is heading
	public:
		Duck2():DuckBase(200,200,"duck2.bmp","duck2Mask.bmp",3,0)
		{
			d_CurrentPos.setX(200);
			d_CurrentPos.setY(200);
			d_Destination.setX(350);
			d_Destination.setY(300);
        }
	    float x() const
		{
			return d_CurrentPos.x();
		}
		float y() const
		{
			return d_CurrentPos.y();
		}
		void setDest(double dx,double dy)
		{
			d_Destination.setX(dx);
			d_Destination.setY(dy);
		}
		float dirX() const
		{
			return d_Destination.x();
		}
		float dirY() const
		{
			return d_Destination.y();
		}
		Vector dest()
		{
               return d_Destination;
        }
        Vector position()
        {
               return d_CurrentPos;
        }
		void move()
		{
			Vector dirVector(Vector::direction(d_CurrentPos,d_Destination));
			d_CurrentPos.setX((d_CurrentPos.x()+dirVector.x()));
			d_CurrentPos.setY((d_CurrentPos.y()+dirVector.y()));

		}
		

};

#endif
