//Author: Jerome Byrne

#include "stdafx.h"
#include <stdlib.h>

/*****************************************************************************

Start a WIN32 Application Project in Visual C++, add in this file
No other libs are required


*****************************************************************************/

//////////////////////////////////////////////////////////////////////////////
//INCLUDES
//////////////////////////////////////////////////////////////////////////////
#define WIN32_LEAN_AND_MEAN 

#include <windows.h>  
#include <windowsx.h>
#include "blood.h"
#include "gun.h"
#include "bomb.h"
#include "duckBase.h"
#include "Duck2.h"
#include "bullethole.h"
#include <Mmsystem.h>
#include <time.h>
#include "explosion.h"
#include "background.h"
#include "cloth.h"
#include "stats.h"
#include <string>
#include "clip.h"
//////////////////////////////////////////////////////////////////////////////
//DEFINES
//////////////////////////////////////////////////////////////////////////////
//name for our window class
#define WINDOWCLASS "win32ex1"
//title of the application
#define WINDOWTITLE "Duck Hunt"

//////////////////////////////////////////////////////////////////////////////
//PROTOTYPES
//////////////////////////////////////////////////////////////////////////////
bool Prog_Init();//game data initalizer
void Prog_Loop();//main game loop
void Prog_Done();//game clean up

//////////////////////////////////////////////////////////////////////////////
//GLOBALS
//////////////////////////////////////////////////////////////////////////////
HINSTANCE hInstMain=NULL;//main application handle
HWND hWndMain=NULL;//handle to our main window

void ShowBitmap(HDC hdc, HBITMAP img, int x, int y,DWORD rop3=SRCCOPY){
	

	HDC memoryDC=CreateCompatibleDC(hdc); //create a memoryDC
	
	BITMAP bm;
	GetObject(img,sizeof(BITMAP), (LPVOID)&bm); //use getObject to get ifo about the bitmap
												// the struct bm will contain the bitmap size

	SelectObject(memoryDC,img); //select the bitmap into the memorydc

	BitBlt(			// copy the bitmap data from one dc to another
		hdc,		// destinatioion dc
		x,			// coordinate to start copying To
		y,
		bm.bmWidth,	// width and height of data to copy
		bm.bmHeight,
		memoryDC,	// source DC
		0,			// coordinate to start copying FROM
		0, 
		rop3);

	DeleteDC(memoryDC);
}
POINT preMouse;
const int MAXDUCKS=40;//the maximum number of ducks
DuckBase duck[MAXDUCKS];//an array of ducks
Duck2 duck2;//a duck2 object
int dCount=0;//the current duck
HPEN scorePen = CreatePen(PS_SOLID, 8, RGB(40, 50, 89));
HPEN hPen = CreatePen(PS_SOLID, 4, RGB(0, 0, 0));
Gun gun;//Includes the target bitmap etc...
static int reloadCount=0;
const int maxBlood=12;
Blood blood[maxBlood];//a blood splatter object
int numBloodObjects=0;
Blood headBlood(0,0,"bloodsplatter3");
bool playingGame=false;//has the main game started
const int maxHoles=30;//max number of bulletHoles
HDC hdc;
HDC hDc;
HDC memDC;
RECT rt;
HBITMAP bmBlank;
bool scopeMode=false;//have you entered sniper mode
RECT duck2Rt;
RECT duckRt;
RECT bombRt;
Bomb bomb(0,rand()%275,"redBomb.bmp","redBombMask.bmp");
Clip clip;
Explosion explosion[13];
int exploCount=0;
const int maxExCount=13;//max number of explosion sprites
int frameTime=0;//counter for the current explosion sprite
Background background;//stores the background bitmaps
int destChangeTime;
Cloth cloth;//a cloth object
Stats stats;//contains score etc...
RECT clipRt;//a rectangle around the clip object
HBITMAP hBtmpReload;
HBITMAP hBtmpReloadMask;
bool controlScreen=false;
bool BITBLIT=false;
POINT mouse;
Duck2 duck3;//a third duck object, this duck will not move 
RECT sniperRt;
HBITMAP hBtmpCongrats;
HBITMAP hBtmpHardluck;
bool resultsScreen=false;
//////////////////////////////////////////////////////////////////////////////
//WINDOWPROC
//////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK TheWindowProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	//which message did we get?
	switch(uMsg)
	{
	case WM_DESTROY://the window is being destroyed
		{

			//tell the application we are quitting
			PostQuitMessage(0);

			//handled message, so return 0
			return(0);

		}break;


	 case WM_MOUSEMOVE://the mouse is moving
		{
			 if(scopeMode==true)
			 {
                mouse.x=LOWORD(lParam);
                mouse.y=HIWORD(lParam);
             }
             preMouse.x=gun.getX();
             preMouse.y=gun.getY();
             gun.setX(LOWORD(lParam)); // get current position
			 gun.setY(HIWORD(lParam));
        }break;

	case WM_RBUTTONDOWN://makes sure the player cant hold the shoot button down
	{
         reloadCount++;
         if(reloadCount>0)
         {
              gun.setJammed(true) ;            
         }
             
     }break;
	case WM_RBUTTONUP://makes sure the player cant hold the shoot button down
	{
         gun.setJammed(false);
             
     }break;
     case WM_PAINT://the window needs repainting
		{  
            //a variable needed for painting information
			PAINTSTRUCT ps;
			//start painting
			hdc=BeginPaint(hwnd,&ps);
			/////////////////////////////
			//painting code would go here
			/////////////////////////////
			GetClientRect(hwnd, &rt);
			BITMAP bmTarget;
			GetObject(gun.getBitmap(),sizeof(BITMAP), (LPVOID)&bmTarget);
			RECT targetRt;
			targetRt.bottom=bmTarget.bmHeight;
			targetRt.right=bmTarget.bmWidth;
            if(playingGame==false&&resultsScreen==false)//if the player is on the menu screen
			{
               if(controlScreen==false)
               {
               background.setBitmap('m');
               memDC=CreateCompatibleDC(hdc);
			   bmBlank=CreateCompatibleBitmap(hdc,rt.right,rt.bottom);
			   SelectObject(memDC,bmBlank);
               ShowBitmap(memDC,background.getBitmap(),0,0,SRCPAINT);
               gun.setBitmap(' ');
               RECT controlsRt;
               controlsRt.bottom=rt.bottom-30;
               controlsRt.top=rt.bottom-90;
               controlsRt.left=rt.right-250;
               controlsRt.right=rt.right-90;
               //SelectObject(memDC,hPen);
               //SelectObject(memDC,GetStockObject(NULL_BRUSH));
               //Rectangle(memDC,controlsRt.left,controlsRt.top,controlsRt.right,controlsRt.bottom);
               RECT startRt;
               startRt.bottom=125;
               startRt.top=107;
               startRt.left=212;
               startRt.right=230;
               //Rectangle(memDC,startRt.left,startRt.top,startRt.right,startRt.bottom);
               //ShowBitmap(memDC,gun.getBitmap(),gun.getX(),gun.getY(),	SRCAND);//shows the target bitmap
			   ShowBitmap(memDC,gun.getBitMask(),gun.getX()-48,gun.getY()-47, SRCPAINT);
			   //gun.setX(mouse.x-(targetRt.right/2));//sets the middle of the target to the mouse 
			   //gun.setY(mouse.y-(targetRt.bottom/2));
			   bool shoot=false;
			   if(GetAsyncKeyState(VK_LBUTTON ))
			   {
                    shoot=true;
               }
			   if(PtInRect(&startRt,gun.point())&&shoot==true)
			   {
                       background.setBitmap(' ');//sets the bitmap to the lake
                       BitBlt(hdc,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
                       ShowBitmap(memDC,background.getBitmap(),0,0,SRCAND); 
                       ShowBitmap(memDC,background.getBitmap(),0,0,SRCPAINT);
                       playingGame=true;   
                   
               }
               else if(PtInRect(&controlsRt,gun.point())&&shoot==true)
               {
                    
                    controlScreen=true;
                    background.setBitmap('i');
               }
               BitBlt(hdc,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
               DeleteDC(memDC);
			   DeleteObject(bmBlank);	
			   ReleaseDC(hWndMain,hdc);
      }
       else if(controlScreen==true)
       {
               memDC=CreateCompatibleDC(hdc);
			   bmBlank=CreateCompatibleBitmap(hdc,rt.right,rt.bottom);
			   SelectObject(memDC,bmBlank);
               ShowBitmap(memDC,background.getBitmap(),0,0,SRCPAINT);
               RECT backRt;
               backRt.bottom=rt.top+40;
               backRt.top=rt.top;
               backRt.left=rt.right-167;
               backRt.right=rt.right;
               //Rectangle(memDC,backRt.left,backRt.top,backRt.right,backRt.bottom);
               bool shoot=false;
               if(GetAsyncKeyState(VK_LBUTTON ))
			   {
                    shoot=true;
               }
               if(PtInRect(&backRt,gun.point())&&shoot==true)
               {
                 controlScreen=false;
               }
               BitBlt(hdc,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
               DeleteDC(memDC);
			   DeleteObject(bmBlank);	
			   ReleaseDC(hWndMain,hdc);
      }        
             }
            else if(playingGame==true&&scopeMode==false)
            {//if playing the game and havent entered scope mode
			duck[dCount].setShow(true);//show the ducks on screen
			gun.setBitmap(' ');//sets the bitmap to the normal target bitmap
			//	DOUBLE BUFFER CODE
            hDc=GetDC(hwnd);
            memDC=CreateCompatibleDC(hdc);
            bmBlank=CreateCompatibleBitmap(hdc,rt.right,rt.bottom);
			SelectObject(memDC,bmBlank);
			ShowBitmap(memDC,background.getBitmap(),background.x(),background.y(),	SRCPAINT);//draws the background image
			//gun.setX(mouse.x-(targetRt.right/2));//sets the middle of the target to the mouse 
			//gun.setY(mouse.y-(targetRt.bottom/2));
			gun.setPreX(preMouse.x-(targetRt.right/2));
			gun.setPreY(preMouse.y-(targetRt.bottom/2));
			if(duck[dCount].show()==true)//if a duck is on screen
			{
				ShowBitmap(memDC,duck[dCount].getBitMask(),duck[dCount].getX(),duck[dCount].getY(),	SRCAND);//shows duck2 the small duck
				ShowBitmap(memDC,duck[dCount].getBitmap(),duck[dCount].getX(),duck[dCount].getY(),	SRCPAINT);
				if(duck[dCount].getY()>rt.bottom||duck[dCount].getX()>rt.right)//||duck[dCount].getY()<rt.top-50)
				{
					duck[dCount].setShow(false);//if the duck moves off the screen then delete the duck
					if(duck[dCount].destroyed()==true)
					{
                           stats.destroyed();//increments the score
                    }
                    else
                    {
                        if(duck[dCount].decapitated()==true)
                        {
                              stats.headHit();
                        }
                        if(duck[dCount].torsoShot()==true)
                        {
                              stats.torsoHit();
                        }
                        if(duck[dCount].wingless()==true)
                        {
                              stats.wingHit();
                        }
                    }
				}
						//duck array rectangle-TORSO
				duckRt.bottom=duck[dCount].getY()+duck[dCount].getRtB();
				duckRt.left=duck[dCount].getX()+30;
				duckRt.right=duck[dCount].getX()+duck[dCount].getRtR()-60;
				duckRt.top=duck[dCount].getY()+80;
				//Rectangle(memDC,duckRt.left,duckRt.top,duckRt.right,duckRt.bottom);
						//HEAD
				RECT headRt;
				headRt.bottom=duck[dCount].getY()+duck[dCount].getRtB()-30;
				headRt.left=duck[dCount].getX()+125;
				headRt.right=duck[dCount].getX()+duck[dCount].getRtR();
				headRt.top=duck[dCount].getY()+70;
			    //Rectangle(memDC,headRt.left,headRt.top,headRt.right,headRt.bottom);
						//WING
				RECT wingRt;
				wingRt.bottom=duck[dCount].getY()+80;
				wingRt.left=duck[dCount].getX()+20;
				wingRt.right=duck[dCount].getX()+80;
				wingRt.top=duck[dCount].getY()+10;
				//Rectangle(memDC,wingRt.left,wingRt.top,wingRt.right,wingRt.bottom);

				if(GetAsyncKeyState(VK_LBUTTON )&&gun.reloaded()==true&&gun.jammed()==false)
                {//if the player shoots and has reloaded
                        gun.setFlashTime(10);
						gun.setClipSize(gun.clipSize()-1);
                        gun.setShoot(true);
			    }
			    else
			    {
			     gun.setShoot(false);
                }
                if(gun.clipSize()<=0)
						{
                             gun.reload(false);
                             //show reload bitmap
                             ShowBitmap(memDC,hBtmpReloadMask,rt.left+50,rt.top+20,	SRCAND);
					         ShowBitmap(memDC,hBtmpReload,rt.left+50,rt.top+20,	SRCPAINT);
                        }
				if(GetAsyncKeyState(VK_RBUTTON ))//reloads your gun
                {
                      reloadCount=0;
                      gun.setClipSize(gun.maxClip());
                      gun.reload(true);
                }
                 if(BITBLIT==true)
                 {
                     //makes sure the screen is being bitblted
                     //  all the time
                     //The screen should only be bitblted for one frame 
                     BITBLIT=false;
                 }
				if(PtInRect(&duckRt,gun.point()))//if the mouse is on the ducks torso
				{
					gun.setBitmap('r');//sets the target to red
					if(gun.shoot()==true&&duck[dCount].destroyed()==false){//if the player shoots
                       if(duck[dCount].getShotDown()==false)
                       {
                           blood[numBloodObjects].setPosition(gun.getX()-70,gun.getY()-40);//sets the position of the blood splatter
                           blood[numBloodObjects].setBlood(true);//sets to true so it can be then shown
                           numBloodObjects++;//increment the number
                           
                               //bitblt the whole screen once
                               //so the blood can be seen fully
                               BITBLIT=true;
                       }
                       if(numBloodObjects>=maxBlood)//if the number of blood splatters is maxed
                       {
                            numBloodObjects=maxBlood-1;
                       }
                       duck[dCount].setTorsoShot(true);//the ducks torso has been shot
                        if(duck[dCount].decapitated()==false&&duck[dCount].wingless()==false)//if the duck hasnt already been decapitated
                        {
                            duck[dCount].setBitmap('t');//set bitmap to bloody torso
                        }
                        else if(duck[dCount].decapitated()==true&&duck[dCount].wingless()==false)
                        {
                            duck[dCount].setMassacred(true);
                            duck[dCount].setBitmap('m');//sets the bitmap to bloody torso and headless
                        }
                        else if(duck[dCount].wingless()==true&&duck[dCount].decapitated()==false)
                        {
                             duck[dCount].setBitmap('M');
                        }
                        else if(duck[dCount].decapitated()==true&&duck[dCount].wingless()==true)
                        {
                             duck[dCount].setBitmap('d');
                        }
                        duck[dCount].shotDown();//the duck is shot down
						}//end of if the player shoots
				}//end of if the mouse is in the rectangle
				else if(PtInRect(&wingRt,gun.point()))//if the mouse is on the ducks wing
				{
					gun.setBitmap('r');//sets the target to red
					if(gun.shoot()==true&&duck[dCount].destroyed()==false)//if the player shoots
                    {//if the player shoots 
                        if(duck[dCount].getShotDown()==false)
                       {
                           blood[numBloodObjects].setPosition(gun.getX()-70,gun.getY()-40);//sets the position of the blood splatter
                           blood[numBloodObjects].setBlood(true);//sets to true so it can be then shown
                           numBloodObjects++;//increment the number

                               //bitblt the whole screen once
                               //so the blood can be seen fully
                               BITBLIT=true;
                       }
                       if(numBloodObjects>=maxBlood)//if the number of blood splatters is maxed
                       {
                            numBloodObjects=maxBlood-1;
                       }
                        duck[dCount].setWingless(true);
                        if(duck[dCount].decapitated()==false&&duck[dCount].torsoShot()==false)
                        {
                            duck[dCount].setBitmap('w');
                        }
                        else if(duck[dCount].decapitated()==true&&duck[dCount].torsoShot()==false)
                        {
                             duck[dCount].setLimbless(true);
                             duck[dCount].setBitmap('l');
                        }
                        else if(duck[dCount].decapitated()==true&&duck[dCount].torsoShot()==true)
                        {
                             duck[dCount].setBitmap('d');
                        }
                        else if(duck[dCount].decapitated()==false&&duck[dCount].torsoShot()==true)
                        {
                             duck[dCount].setBitmap('M');
                        }
                        duck[dCount].shotDown();//the duck is shot
				    }
				}
				else if(PtInRect(&headRt,gun.point())&&duck[dCount].destroyed()==false)//if the mouse is on the ducks head
				{
					gun.setBitmap('r');//sets the target to red
					if(gun.shoot()==true){//if the player shoots
                           duck[dCount].setDecap(true);//the duck has been decapitated
                           if(duck[dCount].torsoShot()==true&&duck[dCount].wingless()==false)//if the duck has already been shot in the torso
                           {
                                duck[dCount].setMassacred(true);
                               duck[dCount].setBitmap('m');//show bloody torso and headless bitmap
                            }
                           else if(duck[dCount].wingless()==false&&duck[dCount].torsoShot()==false)//if the duck hasnt been shot already
                           {
                               duck[dCount].setBitmap('h');//displays a headless duck
                           }
                           else if(duck[dCount].wingless()==true&&duck[dCount].torsoShot()==false)
                           {
                                duck[dCount].setBitmap('l');
                           }
                           else if(duck[dCount].wingless()==true&&duck[dCount].torsoShot()==true)
                           {
                                duck[dCount].setBitmap('d');
                           }
                           duck[dCount].shotDown();//the duck is shot down
					}
				}
    			if(gun.flashTime()>0)//if >0 show muzzle flash
				{
					ShowBitmap(memDC,gun.getFlashMask(),gun.getX()-53,gun.getY()-53,SRCAND);
					ShowBitmap(memDC,gun.getFlash(),gun.getX()-53,gun.getY()-53, SRCPAINT);
					gun.setFlashTime(gun.flashTime()-1);
				}
				if(duck[dCount].getShotDown()==true)//if duck is shot send him down the 
														//screen to be destroyed 
														//and increment score
                {
				           duck[dCount].setY(duck[dCount].getY()+(duck[dCount].ySpeed()));
				           duck[dCount].setX(duck[dCount].getX()+(duck[dCount].xSpeed()));
				}
				else//if the duck is alive
				{
					duck[dCount].setX(duck[dCount].getX()+(duck[dCount].xSpeed()));//if hes not shot send him flying
					int dir=rand()%2;
					if(dir==0)
					{
						duck[dCount].setY(duck[dCount].getY()-rand()%10);//send the duck on an
																		//erratic path
					}
					else if(dir==1)
					{
						duck[dCount].setY(duck[dCount].getY()+rand()%10);//send the duck on an
																		//erratic path
					}
                 }
            }
            if(dCount==4
               ||dCount==9
               ||dCount==15
               ||dCount==24
               ||dCount==34
               ||dCount==50
               ||dCount==78
               ||dCount==90)//a bomb goes down the screen if true
            {
                  bomb.setShow(true);
                  //clip.setShow(true);
            }
            if(clip.show()==true)
            {
                clipRt.right=clip.x()+40;
                clipRt.left=clip.x()-5;
                clipRt.top=clip.y()-10;
                clipRt.bottom=clip.y()+40;
                //Rectangle(memDC,bombRt.left,bombRt.top,bombRt.right,bombRt.bottom);
                ShowBitmap(memDC,clip.getBitMask(),clip.x(),clip.y(), SRCAND);
                ShowBitmap(memDC,clip.getBitmap(),clip.x(),clip.y(), SRCPAINT);
                clip.move(1); 
                if(clip.y()>rt.bottom)//if a bomb has gone off the screen dont show it and give it a new starting position
                {
                    clip.setShow(false);
                    clip.setPos(rand()%600,-70);
                    clip.setDest(rand()%600,600);
                }                  
            }
            if(bomb.show()==true)//If a bomb is being shown
            {
                bombRt.right=bomb.x()+40;
                bombRt.left=bomb.x()-5;
                bombRt.top=bomb.y()-10;
                bombRt.bottom=bomb.y()+40;
                //Rectangle(memDC,bombRt.left,bombRt.top,bombRt.right,bombRt.bottom);
                ShowBitmap(memDC,bomb.getBitMask(),bomb.x(),bomb.y(), SRCAND);
                ShowBitmap(memDC,bomb.getBitmap(),bomb.x(),bomb.y(), SRCPAINT);
                bomb.move((rand()%3)+1);
                if(PtInRect(&bombRt,gun.point())==true&&gun.shoot()==true)
                {
                       bomb.setShow(false);
                       stats.bombHit();
                       explosion[exploCount].setPosition(bomb.x()-40,bomb.y()-40);
                       explosion[exploCount].setShow(true);//initialises an explosion animation
                       bomb.setPos(rand()%600,-70); 
                       bomb.setDest(rand()%600,600);
                       duck[dCount].shotDown();
                        if(duck[dCount].getShotDown()==true)
                       {
                           blood[numBloodObjects].setPosition(duck[dCount].getX(),duck[dCount].getY());//sets the position of the blood splatter
                           blood[numBloodObjects].setBlood(true);//sets to true so it can be then shown
                           numBloodObjects++;//increment the number
                       }
                       if(numBloodObjects>=maxBlood)//if the number of blood splatters is maxed
                       {
                            numBloodObjects=maxBlood-1;
                       }
                       duck[dCount].setBitmap('d');
                       duck[dCount].setDestroyed(true);
                }
                if(bomb.x()<rt.left||bomb.x()>rt.right)
                {//if a bomb has gone off the screen dont show it and give it a new starting position
                    bomb.setShow(false);
                    bomb.setPos(rand()%600,-70);
                    bomb.setDest(rand()%600,600);
                }
                if(bomb.y()>rt.bottom)//if a bomb has gone off the screen dont show it and give it a new starting position
                {
                    bomb.setShow(false);
                    bomb.setPos(rand()%600,-70);
                    bomb.setDest(rand()%600,600);
                }               
            }//end of if bomb is being shown
            if(explosion[exploCount].show()==true)//if an explosion is being shown
            {
                //shows an explosion frame
               ShowBitmap(memDC,explosion[exploCount].getBitmap(),explosion[exploCount].x(),explosion[exploCount].y(), SRCPAINT);
               if(exploCount<maxExCount-1)
               {
                   BITBLIT=true;
                   if(exploCount==2)//changes the background to a brighter bitmap to give an explosion effect
                   {
                       background.setBitmap('x');     
                   }
                   else if(exploCount>=0&&exploCount<2||exploCount>2&&exploCount<=6)
                   {
                        background.setBitmap('e');
                   }
                   else
                    background.setBitmap(' ');
                   explosion[exploCount+1].setPosition(explosion[exploCount].x(),explosion[exploCount].y());
                   explosion[exploCount+1].setShow(true);
                   frameTime++;
                   if(frameTime>=9)
                   {
                       explosion[exploCount].setShow(false);
                       exploCount++;
                       frameTime=0;
                   }
               }
               else
               {
                   exploCount=0;  
               }  
            }
			ShowBitmap(memDC,gun.getBitMask(),gun.getX()-48,gun.getY()-47, SRCPAINT);//show sthe target bitmap
			for(int count=0;count<numBloodObjects;count++)//shows all the valid blood objects
			{
                 if(blood[count].showBlood()==true)//if the duck has been shot in the torso
			     {     //show the blood splatter bitmap
                       ShowBitmap(memDC,blood[count].getBitmap(),blood[count].position().x(),blood[count].position().y(),SRCAND);
                 }
            }     
			//SelectObject(memDC,scorePen);
			//TextOut(memDC,500,30,"SCORE",5);
			char buffer[11];
			char ducksLeft[10];
			sprintf(buffer,"%d\n",stats.Score());
			sprintf(ducksLeft,"%d\n",(MAXDUCKS-dCount)-2);
			TextOutA(memDC,rt.right/1.65,rt.top+20,buffer,4);
            TextOutA(memDC,rt.left+170,rt.bottom-85,ducksLeft,3);
			if(duck[dCount].show()==false)// if the duck is off screen
			{
				duck[dCount].~DuckBase();//destructor deletes the bitmaps
				if(dCount<MAXDUCKS-1)
				{
					dCount++;
				}
			}
			if(GetAsyncKeyState(VK_SPACE ))
			{
                   //clears the screen of blood
                cloth.setShow(true);
                numBloodObjects=0;
                ShowBitmap(memDC,cloth.getBitMask(),cloth.position().x(),cloth.position().y(),SRCAND);
                ShowBitmap(memDC,cloth.getBitmap(),cloth.position().x(),cloth.position().y(),SRCPAINT);
                cloth.move();
                if(cloth.position().x()>rt.right)
                {
                     //cloth.setShow(false);
                    cloth.setX(0);
                   
                }
                
            } 
            
            if(BITBLIT==true)//if a bomb goes off or a duck is shot bitblit the whole screen
            {
                BitBlt(hdc,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
            }
            else
            {
                //BitBlt(hdc,gun.getX(),gun.getY(),targetRt.right,targetRt.bottom,memDC,gun.getX(),gun.getY(),SRCCOPY);
                BitBlt(hdc,gun.preX(),gun.preY(),targetRt.right,targetRt.bottom,memDC,gun.preX(),gun.preY(),SRCCOPY);//bitblits the gun area
                BitBlt(hdc,rt.left+170,rt.bottom-85,20,20,memDC,rt.left+170,rt.bottom-85,SRCCOPY);//bitblits the ducks left area
                BitBlt(hdc,50,10,140,70,memDC,50,10,SRCCOPY);//bitblits the reload area
                BitBlt(hdc,477,20,30,20,memDC,477,20,SRCCOPY);
                //bitblits the ducks rectangle
                BitBlt(hdc,duckRt.left-50,duckRt.top-80,duck[dCount].rect().right+20,duck[dCount].rect().bottom+30,memDC,duckRt.left-50,duckRt.top-80,SRCCOPY);
                //bitblits the bombs rectangle
                BitBlt(hdc,bomb.x()-5,bomb.y()-7,bombRt.right-(bombRt.left),bombRt.bottom-(bombRt.top),memDC,bomb.x()-5,bomb.y()-7,SRCCOPY);
                if(cloth.show()==true)
                {
                         BitBlt(hdc,cloth.position().x(),cloth.position().y(),cloth.rect().right,cloth.rect().bottom,memDC,cloth.position().x(),cloth.position().y(),SRCCOPY);
                }
                
            };
            DeleteDC(memDC);
			DeleteObject(bmBlank);	
			ReleaseDC(hWndMain,hdc);
			if(dCount>=MAXDUCKS-1)
			{
                   duck[MAXDUCKS-1].~DuckBase();
                   background.setBitmap('z');
                   scopeMode=true;
                   
                   playingGame=false;
                   resultsScreen=true;
            }
			//end painting
        }//end of else-playing the game and scope mode =false
        //THE FOLLOWING IS PART OF THE GAME I NEVER GOT TO FINISH
        //UNCOMMENT AND SET scopeMode TO TRUE TO SEE
        else if(playingGame==true&&scopeMode==true)//if you have reached the second part of the game/sniperMode
        {
             background.setBitmap('z');
             duck3.setShow(true);
             duck2.setShow(true);
             memDC=CreateCompatibleDC(hdc);
             bmBlank=CreateCompatibleBitmap(hdc,rt.right,rt.bottom);
			 SelectObject(memDC,bmBlank);
			 ShowBitmap(memDC,background.getBitmap(),background.x(),background.y(),SRCPAINT);
			 if(duck3.show()==true)
			 {
                 ShowBitmap(memDC,duck3.getBitMask(),background.x()+500,background.y()+500,	SRCAND);//shows the big duck
                 ShowBitmap(memDC,duck3.getBitmap(),background.x()+500,background.y()+500,	SRCPAINT);
             }
			 if(duck2.show()==true)
			 {
                  //duck2 rectangle
				duck2Rt.bottom=duck2.y()+duck2.getRtB();
				duck2Rt.left=duck2.x()+30;
				duck2Rt.right=duck2.x()+duck2.getRtR()-15;
				duck2Rt.top=duck2.y()+30;
				//Rectangle(memDC,duck2Rt.left,duck2Rt.top,duck2Rt.right,duck2Rt.bottom);
                ShowBitmap(memDC,duck2.getBitMask(),duck2.x(),duck2.y(),	SRCAND);//shows the big duck
                ShowBitmap(memDC,duck2.getBitmap(),duck2.x(),duck2.y(),	SRCPAINT);
                
                if(destChangeTime==100)
                {
                      duck2.setDest(rand()%rt.right,rand()%rt.bottom);
                }   
                duck2.move();
             }
             background.move(mouse.x-800,mouse.y-600); 
             //Rectangle(memDC,sniperRt.left,sniperRt.top,sniperRt.right,sniperRt.bottom);
             gun.setBitmap('s');
             gun.setX(0);
             gun.setY(0);
             ShowBitmap(memDC,gun.getBitmap(),gun.getX(),gun.getY(),SRCAND);//shows the target bitmap
             BitBlt(hDc,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
             destChangeTime++;
             if(destChangeTime>100)
             {
                  destChangeTime=0;
             }
             DeleteDC(memDC);
			 DeleteObject(bmBlank);
             ReleaseDC(hWndMain,hDc);
             
        }
      else if(resultsScreen==true)//shows how you did?
      {
               memDC=CreateCompatibleDC(hdc);
			   bmBlank=CreateCompatibleBitmap(hdc,rt.right,rt.bottom);
			   SelectObject(memDC,bmBlank);
			   if(stats.Score()>1300)//the number of points you need to win
			   {
                    ShowBitmap(hdc,hBtmpCongrats,0,0,SRCAND);
                    ShowBitmap(hdc,hBtmpCongrats,0,0,SRCPAINT);
               }
               else
               {
                   ShowBitmap(hdc,hBtmpHardluck,0,0,SRCAND);
                    ShowBitmap(hdc,hBtmpHardluck,0,0,SRCPAINT);
               }
               if(GetAsyncKeyState(VK_RBUTTON ))
			   {
                    dCount=0;
                    resultsScreen=false;
                    for(int i=0;i<MAXDUCKS;i++)
                    {
                            duck[i].setShow(true);
                    }
                    
               }
               BitBlt(memDC,0,0,rt.right,rt.bottom,memDC,0,0,SRCCOPY);
               DeleteDC(memDC);
			   DeleteObject(bmBlank);	
			   ReleaseDC(hWndMain,hdc);
      }
			EndPaint(hwnd,&ps);
            //handled message, so return 0
			return(0);
		}break;
	}

	//pass along any other message to default message handler
	return(DefWindowProc(hwnd,uMsg,wParam,lParam));
}


//////////////////////////////////////////////////////////////////////////////
//WINMAIN
//////////////////////////////////////////////////////////////////////////////
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd)
{
	//assign instance to global variable
	hInstMain=hInstance;

	//create window classstructure
	WNDCLASSEX wcx;

	//set the size of the 
	wcx.cbSize=sizeof(WNDCLASSEX);

	//class style
	wcx.style=CS_OWNDC | CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;

	//window procedure
	wcx.lpfnWndProc=TheWindowProc;

	//class extra
	wcx.cbClsExtra=0;

	//window extra
	wcx.cbWndExtra=0;

	//application handle
	wcx.hInstance=hInstMain;

	//icon
	wcx.hIcon=LoadIcon(NULL,IDI_APPLICATION);

	//cursor
	wcx.hCursor=LoadCursor(NULL,IDC_ARROW);

	//background color
	wcx.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);

	//menu
	wcx.lpszMenuName=NULL;

	//class name
	wcx.lpszClassName=WINDOWCLASS;

	//small icon
	wcx.hIconSm=NULL;

	//register the window class, return 0 if not successful
	if(!RegisterClassEx(&wcx)) return(0);

	//create main window
	hWndMain=CreateWindowEx(0,WINDOWCLASS,WINDOWTITLE, WS_BORDER | WS_SYSMENU | WS_VISIBLE|WS_SIZEBOX,0,0,800,636,NULL,NULL,hInstMain,NULL);

	//error check
	if(!hWndMain) return(0);

	//if program initialization failed, then return with 0
	if(!Prog_Init()) return(0);

	//message structure
	MSG msg;

	//message pump
	for(;;)	
	{
		//look for a message
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			//there is a message

			//check that we arent quitting
			if(msg.message==WM_QUIT) break;
			
			//translate message
			TranslateMessage(&msg);

			//dispatch message
			DispatchMessage(&msg);
		}

		//run main game loop
		Prog_Loop();
	}
	
	//clean up program data
	Prog_Done();

	//return the wparam from the WM_QUIT message
	return(msg.wParam);
}

//////////////////////////////////////////////////////////////////////////////
//INITIALIZATION
//////////////////////////////////////////////////////////////////////////////
bool Prog_Init()
{
	////////////////////////////////////
	//your initialization code goes here
	///////////////////////////////////
	hBtmpCongrats=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"congrats.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
	hBtmpHardluck=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"hardluck.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
	hBtmpReload=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"reload.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
	hBtmpReloadMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"reloadmask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
	explosion[0].loadBitmap("explosion1.bmp");
	explosion[1].loadBitmap("explosion2.bmp");
	explosion[2].loadBitmap("explosion3.bmp");
	explosion[3].loadBitmap("explosion4.bmp");
	explosion[4].loadBitmap("explosion5.bmp");
	explosion[5].loadBitmap("explosion6.bmp");
	explosion[6].loadBitmap("explosion7.bmp");
	explosion[7].loadBitmap("explosion8.bmp");
	explosion[8].loadBitmap("explosion9.bmp");
	explosion[9].loadBitmap("explosion10.bmp");
	explosion[10].loadBitmap("explosion11.bmp");
	explosion[11].loadBitmap("explosion12.bmp");
	explosion[12].loadBitmap("explosion13.bmp");
	bomb.setShow(true);
    sniperRt.right=416;
    sniperRt.left=378;
    sniperRt.bottom=320;
    sniperRt.top=278;		
	return(true);//return success
}

//////////////////////////////////////////////////////////////////////////////
//CLEANUP
//////////////////////////////////////////////////////////////////////////////
void Prog_Done()
{
	//////////////////////////
	//clean up code goes here
	//////////////////////////
	DeleteDC(memDC);
    DeleteObject(bmBlank);	
	for(int count=0;count<maxBlood;count++)
	{
            blood[count].~Blood();
    }
	gun.~Gun();
	cloth.~Cloth();
	clip.~Clip();
	duck2.delBitmaps();
	background.~Background();
	DeleteObject(hPen);
	DeleteObject(scorePen);
	bomb.~Bomb();
	DeleteObject(hBtmpReloadMask);
	DeleteObject(hBtmpReload);
	for(int count=0;count<maxExCount;count++)
	{
         explosion[count].~Explosion();
     }
	
}

//////////////////////////////////////////////////////////////////////////////
//MAIN GAME LOOP
//////////////////////////////////////////////////////////////////////////////
void Prog_Loop()
{
	///////////////////////////
	//main game logic goes here
	///////////////////////////
	// control frame rate
	timeBeginPeriod(1); // set timing resolution to 1 millisecond
	static long old_time=0,new_time=0;
	static int  since_last_update=0;
	static int num_frames=0;

	long elapsed;
	new_time=timeGetTime();
	elapsed=new_time-old_time;
	while(elapsed<1){
		Sleep(1);
		new_time=timeGetTime();
		elapsed=new_time-old_time;
	
	}
	num_frames++;
	old_time=new_time;

// display frame rate
	since_last_update+=elapsed;
	if(since_last_update>1000){

		float frame_rate=1000.0f/(float)elapsed;
		char text[100];
		sprintf(text,"Frame rate: %4.1f frames per second",frame_rate);
		SetWindowText(hWndMain,text);
		since_last_update=0;
	}
	InvalidateRect(hWndMain,NULL,false);
	
}
