//Author: Jerome Byrne
#include "vector.h"
#ifndef BLOOD_H
#define BLOOD_H
class Blood{
      private:
              Vector d_position;
              HBITMAP hBtmpBlood;
              HBITMAP hBtmpBlood2;
              bool d_showBlood;
              RECT d_rect;
              BITMAP bmBlood;
      public:
             Blood(float x=0,float y=0,char* s="bloodspray.bmp")
             {//start of constructor
             d_position.setX(x);
             d_position.setY(y);
             d_showBlood=false;
             hBtmpBlood=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				s,	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
            hBtmpBlood2=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"bloodspray3.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
             GetObject(hBtmpBlood,sizeof(BITMAP), (LPVOID)&bmBlood);
             d_rect.right=bmBlood.bmWidth;
             d_rect.bottom=bmBlood.bmHeight;
             d_rect.top=0;
             d_rect.left=0;
             }//end of constructor
             RECT rect() const
             {
                  return d_rect;
             }
             ~Blood()//destructor
             {                   
                    DeleteObject(hBtmpBlood); 
                    DeleteObject(hBtmpBlood2);    
             }
             void setBitmap(int i)
             {
                  if(i==2)
                  {
                      hBtmpBlood=hBtmpBlood2;      
                  }
             }
             HBITMAP getBitmap() const
             {
                     return hBtmpBlood;
             }
             bool showBlood()//Is the blood being shown
             {
                  return d_showBlood;
              }
              void setBlood(bool b)
              {
                   d_showBlood=b;
              }
              void setPosition(float x,float y)
              {
                   d_position.setX(x);
                   d_position.setY(y);
              }
              Vector position() const
              {
                     return d_position;
              }
              
};
#endif
