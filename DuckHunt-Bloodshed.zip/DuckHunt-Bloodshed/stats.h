//Author: Jerome Byrne
#ifndef STATS_H
#define STATS_H
class Stats
{
      private:
          int d_score;
      public:
          Stats()
          {
                 d_score=0;
          }
          int Score() const
          {
              return d_score;
          }
          void bombHit()
          {
               d_score=d_score+25;
          }
          void headHit()
          {
               d_score=d_score+50;
          }
          void torsoHit()
          {
               d_score=d_score+25;
          }
          void wingHit()
          {
               d_score=d_score+25;
          }
          void destroyed()
          {
               d_score=d_score+75;
          }
};
#endif
