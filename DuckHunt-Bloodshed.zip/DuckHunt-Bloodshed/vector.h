//Author: Jerome Byrne
#include <cmath>
#ifndef VECTOR_H
#define VECTOR_H

class Vector{
private:
	float d_x;
	float d_y;
public:
	Vector(float x=0,float y=0)
	{
		d_x=x;
		d_y=y;
	}
	float x() const
	{
		return d_x;
	}
	float y() const
	{
		return d_y;
	}
	void setX(float x)
	{
		d_x=x;
	}
	void setY(float y)
	{
		d_y=y;
	}
	float length() const
	{
		return sqrt(x()*x()+y()*y());
	}
	static Vector direction(Vector &src,Vector &dest)
	{
		Vector temp( dest.x() - src.x(), dest.y() - src.y());
		float length=temp.length();
		return Vector(temp.x() / length, temp.y() / length);
	}
};
#endif
