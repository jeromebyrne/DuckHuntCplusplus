//Author: Jerome Byrne
#include "bomb.h"
#ifndef CLIP_H
#define CLIP_H
class Clip:public Bomb 
{
      public:
         Clip():Bomb(0,rand()%275,"clip.bmp","clipMask.bmp")
         {
         }
         ~Clip()
         {
                DeleteObject(Bomb::getBitmap());
                DeleteObject(Bomb::getBitMask());
         }
         
};
#endif
