//Author: Jerome Byrne
#include "vector.h"
#ifndef BULLETHOLE_H
#define BULLETHOLE_H
class BulletHole{
      private:
              Vector position;
              HBITMAP hBtmpHole;//a bullet hole bitmap
              HBITMAP hBtmpHoleMask;
      public:
             BulletHole()
             {
                hBtmpHole=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"bulletHole.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
				
		        hBtmpHoleMask=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"bulletHoleMask.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
             }
             ~BulletHole()
             {
                  DeleteObject(hBtmpHole);
                  DeleteObject(hBtmpHoleMask);
             }
             HBITMAP getBitmap()
             {
                     return hBtmpHole;
             }
             HBITMAP getBitMask()
             {
                     return hBtmpHoleMask;
             }
             float x()
             {
                   return position.x();
             }
             float y()
             {
                   return position.y();
             }
             void setX(float x)
             {
                  position.setX(x);
             }
             void setY(float y)
             {
                  position.setY(y);
             }
             
      };
#endif
