//Author: Jerome Byrne
#ifndef BACKGROUND_H
#define BACKGROUND_H
class Background{
      private:
        HBITMAP hBtmpBitmap;
        HBITMAP hBtmpBitmapEx;
        HBITMAP hBtmpBitmapEx2;
        HBITMAP hBtmpCurrent;//stores the current bitmap
        HBITMAP hBtmpMenu;
        HBITMAP hBtmpZoomed;
        HBITMAP hBtmpInstructions;
        POINT position;
      public:
             Background()
             {
               position.x=0;
               position.y=0;
               hBtmpInstructions=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"controlsRules.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);          
               hBtmpMenu=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"menuScreen.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
               hBtmpBitmap=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"lake.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
               hBtmpBitmapEx=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"copylake.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
               hBtmpBitmapEx2=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"whitelake.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
			   hBtmpZoomed=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"zoom.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
				hBtmpCurrent=hBtmpBitmap;
             }
             ~Background()
             {
                          DeleteObject(hBtmpCurrent);
                          DeleteObject(hBtmpMenu);
                          DeleteObject(hBtmpBitmap);
                          DeleteObject(hBtmpBitmapEx);
                          DeleteObject(hBtmpBitmapEx2);
                          DeleteObject(hBtmpZoomed);
                          DeleteObject(hBtmpInstructions);
             }
             HBITMAP getBitmap()
             {
                     return hBtmpCurrent;
             }
             int x()
             {
                   return position.x;
             }
             int y()
             {
                   return position.y;
             }
             void move(float x, float y)
             {
                  position.x=x;
                  position.y=y;
                  
             }
             void setBitmap(char b)
             {
                  
                  if(b=='e')
                  {
                          hBtmpCurrent=hBtmpBitmapEx;
                  }
                  else if(b=='x')
                  {
                       hBtmpCurrent=hBtmpBitmapEx2;
                  }
                  else if(b=='m')
                  {
                       hBtmpCurrent=hBtmpMenu;
                  }
                  else if(b=='z')
                  {
                      hBtmpCurrent=hBtmpZoomed; 
                  }
                  else if(b=='i')
                  {
                       hBtmpCurrent=hBtmpInstructions;
                  }
                  else
                    hBtmpCurrent=hBtmpBitmap;
             }
      };

#endif
