//Author: Jerome Byrne
#include "vector.h"
#ifndef CLOTH_H
#define CLOTH_H
class Cloth
{
      private:
              Vector d_position;
              HBITMAP hBtmpClothMask;
              HBITMAP hBtmpCloth;
              RECT d_rect;
              bool d_show;
              public:
              Cloth()
              {
                d_show=false;
			    d_rect.bottom=400;
			    d_rect.right=300;
			    d_rect.top=0;
			    d_rect.left=0;
                hBtmpCloth=(HBITMAP)LoadImage(
				     NULL,			// dont worry, leave as null
				     "cloth.bmp",	// name of the file to be loaded
				     IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				     0,				// leave as 0
				     0,				// leave as 0
				     LR_LOADFROMFILE
				     );
	            hBtmpClothMask=(HBITMAP)LoadImage(
				     NULL,			// dont worry, leave as null
				     "clothMask.bmp",	// name of the file to be loaded
				     IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				     0,				// leave as 0
				     0,				// leave as 0
				     LR_LOADFROMFILE
				     );
                     d_position.setX(0);
                     d_position.setY(100);
              } 
              ~Cloth()
              {
                    DeleteObject(hBtmpCloth);
                    DeleteObject(hBtmpClothMask);  
              }
              RECT rect() const
              {
                   return d_rect;
              } 
              Vector position() const
              {
                     return d_position;
              } 
              HBITMAP getBitmap() const
              {
                      return hBtmpCloth;
              }
              HBITMAP getBitMask() const
              {
                      return hBtmpClothMask;
              }
              void setX(float x)
              {
                   d_position.setX(x);
              } 
              void move()
              {
                    d_position.setX(d_position.x()+5);
              }
              bool show() const
              {
                   return d_show;
              }  
              void setShow(bool b)
              {
                   d_show=b;
              } 
};
#endif
