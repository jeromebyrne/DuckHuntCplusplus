//Author: Jerome Byrne
#include "vector.h"
#ifndef EXPLOSION_H
#define EXPLOSION_H
class Explosion{
      private:
          Vector position;
          HBITMAP hBtmpBitmap;
          bool d_show;
      public:
          Explosion()
          {
             d_show=false;
             hBtmpBitmap=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				"explosion1.bmp",	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
          }
          ~Explosion()
          {
                      DeleteObject(hBtmpBitmap);
          }
          HBITMAP getBitmap() const
          {
                  return hBtmpBitmap;
          }
          void loadBitmap(char* s)
          {
               hBtmpBitmap=(HBITMAP)LoadImage(
				NULL,			// dont worry, leave as null
				s,	// name of the file to be loaded
				IMAGE_BITMAP,	// load a bitmap as opposed to a cursor or icon
				0,				// leave as 0
				0,				// leave as 0
				LR_LOADFROMFILE
				);
          }
          bool show()
          {
               return d_show;
          }
          void setShow(bool b)
          {
               d_show=b;
          }
          float x()
          {
                return position.x();
          }
          float y()
          {
                return position.y();
          }  
          void setPosition(float x,float y)
          {
               position.setX(x);
               position.setY(y);
          }      
      };
#endif
